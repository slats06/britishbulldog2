For this to import the necessary modules you must make sure you have the
modules4all repo source added into your very own repo. If you've already used
the repository creator at http://totalrevolution.tv/create_repo.php then it will already be setup, if not
then use it to create a repo and copy the modules4all section into your own repo addon.xml.

<h3>ONCE ADD-ON IS INSTALLED:</h3>
Go through the default.py and read the comments for each section.
Enable each section in the Main_Menu() function one by one and start to see your add-on come to life!


<h3>Frequently Asked Questions:</h3>
Can I use this code commercially?
-- Please look at our TRMC system for commercial options: http://totalrevolution.tv